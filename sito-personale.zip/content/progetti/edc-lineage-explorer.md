---
title: "EDC Lineage Explorer"
date: 2026-06-15
draft: true
tags: ["python", "informatica", "edc", "data-governance"]
categories: ["progetti"]
summary: "Tool per l'esplorazione e analisi del data lineage da Informatica EDC"
ShowToc: true
---

## Descrizione

_Questo è un template di esempio. Modifica o sostituisci con i tuoi progetti reali._

Tool sviluppato per automatizzare l'analisi del data lineage estratto da Informatica Enterprise Data Catalog (EDC). Permette di visualizzare le dipendenze tra asset e generare report di impatto per change management.

## Funzionalità

- Estrazione lineage via API REST EDC
- Costruzione grafo delle dipendenze
- Analisi d'impatto per modifiche schema
- Export in formato visuale
- Generazione report

## Tecnologie

- Python 3.11+
- Informatica EDC API
- NetworkX per graph analysis

## Repository

🔗 [GitHub](https://github.com/thrama/nome-repo)

---

_Ultimo aggiornamento: Giugno 2024_
