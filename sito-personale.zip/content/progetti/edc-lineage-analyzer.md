---
title: "EDC Lineage Analyzer"
date: 2026-06-15
draft: false
tags: ["python", "informatica", "edc", "data-governance"]
categories: ["progetti"]
summary: "Tool Python per l'analisi e visualizzazione del data lineage estratto da Informatica EDC"
ShowToc: true
---

## Descrizione

Tool sviluppato per automatizzare l'analisi del data lineage estratto da Informatica Enterprise Data Catalog (EDC). Permette di visualizzare le dipendenze tra asset e generare report di impatto per change management.

## Funzionalità

- Estrazione lineage via API REST EDC
- Costruzione grafo delle dipendenze
- Analisi d'impatto per modifiche schema
- Export in formato visuale (GraphViz, Mermaid)
- Generazione report PDF

## Tecnologie

- Python 3.11+
- NetworkX per graph analysis
- FastAPI per servizio REST
- Rich per CLI

## Repository

🔗 [GitHub - edc-lineage-analyzer](https://github.com/lorenzolombardi/edc-lineage-analyzer)

## Screenshot

*[Inserire screenshot o diagrammi]*

---

## Installazione

```bash
pip install edc-lineage-analyzer
```

## Utilizzo Base

```python
from edc_lineage import EDCClient

client = EDCClient(
    host="edc.company.com",
    username="user",
    password="***"
)

lineage = client.get_lineage("schema.table_name")
lineage.visualize()
```

---

*Ultimo aggiornamento: Giugno 2024*
